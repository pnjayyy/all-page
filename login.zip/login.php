<?php

// check if the user is already logged in , redirect to the dashboard page
session_start();

 if(isset($_SESSION['email']))
 {
    header('Location: dashboard.php');
 }

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JWR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgb(139, 187, 241);
        }

        .container {
            width: 900px;
            display: flex;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(30, 137, 236, 0.08);
            animation: slideUp 0.6s ease-out;
            overflow: hidden;
        }

        .login-section {
            width: 50%;
            padding: 2.5rem;
        }

        .image-section {
            width: 50%;
            background-image: url('/api/placeholder/450/600');
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(139, 187, 241, 0.2);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 2rem;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        h1 i {
            color: #444;
            font-size: 2rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .form-group input {
            width: 100%;
            padding: 1rem;
            border: 2px solid #eee;
            border-radius: 50px;
            outline: none;
            font-size: 1rem;
            background: transparent;
            transition: all 0.3s ease;
        }

        .form-group label {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: white;
            padding: 0 0.5rem;
            color: #666;
            pointer-events: none;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group input:not(:placeholder-shown) {
            border-color: #333;
        }

        .form-group input:focus ~ label,
        .form-group input:not(:placeholder-shown) ~ label {
            top: 0;
            font-size: 0.85rem;
            color: #333;
        }

        button {
            width: 100%;
            padding: 1rem;
            color: white;
            border: none;
            border-radius: 50px;  /* เพิ่มความโค้งมนของปุ่ม */
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1rem;
            background: linear-gradient(135deg, rgb(139, 187, 241) 0%, rgb(51, 138, 238) 100%);  /* เพิ่ม gradient */
            box-shadow: 0 4px 15px rgba(51, 138, 238, 0.2);  /* เพิ่มเงา */
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(51, 138, 238, 0.3);  /* เพิ่มเงาตอน hover */
            background: linear-gradient(135deg, rgb(51, 138, 238) 0%, rgb(41, 128, 228) 100%);  /* gradient เข้มขึ้นตอน hover */
        }

        button:active {
            transform: translateY(0);
            box-shadow: 0 2px 10px rgba(51, 138, 238, 0.2);  /* ลดเงาตอนกด */
        }

        .register-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #666;
        }

        .register-link a {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .register-link a:hover {
            color: #000;
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: slideDown 0.4s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert.error {
            background: #fee2e2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }

        .alert.success {
            background: #dcfce7;
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .loading-overlay.active {
            opacity: 1;
            pointer-events: all;
        }

        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #333;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
                flex-direction: column;
            }

            .login-section,
            .image-section {
                width: 100%;
            }

            .image-section {
                height: 200px;
                order: -1;
            }

            .login-section {
                padding: 1.5rem;
            }
        }

        .image-section {
        width: 50%;
        background-image: url('images/logo/logoweb.jpg'); /* แก้ไขพาธให้ตรงกับที่คุณเก็บรูป */
        background-size: cover;
        background-position: center;
        position: relative;
        }

    </style>
</head>
<body>
    <div class="loading-overlay">
        <div class="loading-spinner"></div>
    </div>

    <div class="container">
        <div class="login-section">
            <?php
            if (isset($_SESSION['error'])) {
                echo '<div class="alert error">
                        <p>' . $_SESSION['error'] . '</p>
                        <span class="close-alert">&times;</span>
                      </div>';
                unset($_SESSION['error']);
            }
            if (isset($_SESSION['success'])) {
                echo '<div class="alert success">
                        <p>' . $_SESSION['success'] . '</p>
                        <span class="close-alert">&times;</span>
                      </div>';
                unset($_SESSION['success']);
            }
            ?>

            <h1><i class="fas fa-box-open"></i> JWR Warehouse</h1>

            <form method="POST" action="login-script.php" id="loginForm">
                <div class="form-group">
                    <input type="email" name="email" id="email" placeholder=" " required>
                    <label for="email">อีเมล</label>
                </div>

                <div class="form-group">
                    <input type="password" name="password" id="password" placeholder=" " required>
                    <label for="password">รหัสผ่าน</label>
                </div>

                <button type="submit" name="login">ล็อกอิน</button>
            </form>

            <div class="register-link">
                ยังไม่ได้เป็นสมาชิก? <a href="register.php">สมัครสมาชิก</a>
            </div>
        </div>
        <div class="image-section">
            <div class="image-overlay"></div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const closeButtons = document.querySelectorAll('.close-alert');
            closeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    this.parentElement.remove();
                });
            });

            const loginForm = document.getElementById('loginForm');
            const loadingOverlay = document.querySelector('.loading-overlay');

            loginForm.addEventListener('submit', function() {
                loadingOverlay.classList.add('active');
                
                setTimeout(() => {
                    loadingOverlay.classList.remove('active');
                }, 2000);
            });

            const inputs = document.querySelectorAll('.form-group input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                input.addEventListener('blur', function() {
                    if (!this.value) {
                        this.parentElement.classList.remove('focused');
                    }
                });
            });
        });
    </script>
</body>
</html>
